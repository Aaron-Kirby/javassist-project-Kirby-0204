package ex04;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtMethod;
import javassist.NotFoundException;
import target.Common;

public class ToClassKirby {
	private static final String PKG_NAME = "target" + ".";

	public static void main(String[] args) {	
		Scanner sc = new Scanner(System.in);
		String[] classList;
		String name = "";
		ArrayList<String> methodAlreadyModded = new ArrayList<String>();
		ArrayList<Class> savedClass = new ArrayList<Class>();
		
		while (true) {
			System.out.println("Please enter one class name and two field names separated by commas (e.g. CommonServiceA, idA, nameA or CommonComponentB, idB, nameB):\n"
					+ "Key \"q\" to quit.");
			String input = sc.nextLine();
			classList = input.split(",");
			for (int i = 0; i < classList.length; i++) {
				classList[i] = classList[i].trim();
				if (classList[i].equals("q")) {
					System.out.println("You have quit the program.");
					System.exit(0);
				}
			}

			if (classList.length != 3) {
				System.out.println("[WRN] Invalid Input");
				for (int i = 0; i < classList.length; i++) {
					classList[i] = null;
				}
			} else {
				name = classList[0];
				String classname = PKG_NAME + name;
				System.out.println("=================================");
				
				try {
					ClassPool pool = ClassPool.getDefault();
					CtClass cc = pool.get(classname);
					CtConstructor declaredConstructor = cc.getDeclaredConstructor(new CtClass[0]);
					
					if(classList[1].equals("idA") || classList[2].equals("idA")) {
						String printBlock = "{ " + "System.out.println(\"idA: \" + idA);" + "System.out.println(\"nameA: \" + nameA);"
								+ " }";
						declaredConstructor.insertAfter(printBlock);
						if (methodAlreadyModded.contains(classList[0])) {
							Class<?> c = savedClass.get(0);
							Common ci = (Common) c.newInstance();
							Common c2 = (Common) c.newInstance();
						}
						else {
							Class<?> c = cc.toClass();
							Common ci = (Common) c.newInstance();
							savedClass.add(c);
						}
						cc.defrost();
						methodAlreadyModded.add(classList[0]);
						for (int i = 0; i < classList.length; i++) {
							classList[i] = null;
						}
					}
					else {
						String printBlock = "{ " + "System.out.println(\"idB: \" + idB);" + "System.out.println(\"nameB: \" + nameB);"
								+ " }";
						declaredConstructor.insertAfter(printBlock);
						if (methodAlreadyModded.contains(classList[0])) {
							Class<?> c = savedClass.get(0);
							Common ci = (Common) c.newInstance();
							Common c2 = (Common) c.newInstance();
						}
						else {
							Class<?> c = cc.toClass();
							Common ci = (Common) c.newInstance();
							savedClass.add(c);
						}
						cc.defrost();
						methodAlreadyModded.add(classList[0]);
						for (int i = 0; i < classList.length; i++) {
							classList[i] = null;
						}
					}
				} catch (NotFoundException | CannotCompileException | InstantiationException | IllegalAccessException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
